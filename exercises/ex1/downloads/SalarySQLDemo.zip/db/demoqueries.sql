-- Simple startup, query the tables to show the data and some typical (simple) analytics
SELECT * FROM "SalarySQLDemo.db::Salaries";
SELECT "zipcode", AVG("salary") FROM "SalarySQLDemo.db::Salaries" GROUP BY "zipcode";
SELECT "start_year", AVG("salary") FROM "SalarySQLDemo.db::Salaries" GROUP BY "start_year";

-- this shows the re-identification, that is why we cannot "just" remove the name to protect the privacy
SELECT * FROM  "SalarySQLDemo.db::Salaries" 
WHERE "start_year" = 1993 and "gender" = 'm' and "zipcode"= 7203 and "education" = 'Bachelor' and "T-Level" = 'T5';

-- this shows the impact on the whole dataset
SELECT "start_year", "gender", "region", "zipcode", "T-Level", "education", count(*), MAX("salary") FROM "SalarySQLDemo.db::Salaries" 
GROUP BY "start_year","gender","region","zipcode","T-Level","education" 
HAVING count(*)=1;

-- dropping i case running the demo twice
DROP VIEW "salaryanon";

-- This creates the anonymized view including EMBEDDED hierarchies (simple to use, but complex to 'type')
CREATE VIEW "salaryanon" ("id", "start_year", "gender", "region", "zipcode", "T-Level", "education", "salary")
AS
SELECT "id", "start_year", "gender", "region", "zipcode", "T-Level", "education", "salary"
FROM "SalarySQLDemo.db::Salaries"
WITH ANONYMIZATION (ALGORITHM 'K-ANONYMITY' PARAMETERS '{"k": 8}'
COLUMN "id" PARAMETERS '{"is_sequence":true}'
COLUMN "gender" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["f"],["m"]]}}'
COLUMN "region" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["APJ"],["EMEA"],["NA"]]}}'
COLUMN "T-Level" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["T1","T1-T2"],["T2","T1-T2"],["T3","T3-T5"],["T4","T3-T5"],["T5","T3-T5"]]}}'
COLUMN "education" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["9th-12th","High School","Secondary Ed"],["Assoc-acdm","Professional Ed","Higher Ed"],["Assoc-voc","Professional Ed","Higher Ed"],["Bachelor","Undergraduate","Higher Ed"],["College","Undergraduate","Higher Ed"],["Doctorate","Graduate","Higher Ed"],["HS-grad","High School","Secondary Ed"],["Master","Graduate","Higher Ed"],["Prof-school","Professional Ed","Higher Ed"]]}}'
COLUMN "zipcode" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["5004","50xx"],["5005","50xx"],["5006","50xx"],["5104","51xx"],["5105","51xx"],["5106","51xx"],["5204","52xx"],["5205","52xx"],["5206","52xx"],["6006","60xx"],["6007","60xx"],["6008","60xx"],["6106","61xx"],["6107","61xx"],["6108","61xx"],["6206","62xx"],["6207","62xx"],["6208","62xx"],["7002","70xx"],["7003","70xx"],["7004","70xx"],["7102","71xx"],["7103","71xx"],["7104","71xx"],["7202","72xx"],["7203","72xx"],["7204","72xx"]]}}'
COLUMN "start_year" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["1987","1986-1990","1986-1995"],["1988","1986-1990","1986-1995"],["1989","1986-1990","1986-1995"],["1990","1986-1990","1986-1995"],["1991","1991-1995","1986-1995"],["1992","1991-1995","1986-1995"],["1993","1991-1995","1986-1995"],["1994","1991-1995","1986-1995"],["1995","1991-1995","1986-1995"],["1996","1996-2000","1996-2005"],["1997","1996-2000","1996-2005"],["1998","1996-2000","1996-2005"],["1999","1996-2000","1996-2005"],["2000","1996-2000","1996-2005"],["2001","2001-2005","1996-2005"],["2002","2001-2005","1996-2005"],["2003","2001-2005","1996-2005"],["2004","2001-2005","1996-2005"],["2005","2001-2005","1996-2005"],["2006","2006-2010",">2006"],["2007","2006-2010",">2006"],["2008","2006-2010",">2006"],["2009","2006-2010",">2006"],["2010","2006-2010",">2006"],["2011","2011-2015",">2006"],["2012","2011-2015",">2006"],["2013","2011-2015",">2006"],["2014","2011-2015",">2006"],["2015","2011-2015",">2006"],["2016","2016-2020",">2006"],["2017","2016-2020",">2006"]]}}');

-- refresh creates the metadata (before its not queryable)
REFRESH VIEW "salaryanon" ANONYMIZATION;

-- shows the resutls
SELECT * FROM "salaryanon";

-- double checks if there are any singled out ones left --> should be empty
SELECT "start_year", "gender", "region", "zipcode", "T-Level", "education", count(*), MAX("salary") FROM "salaryanon" 
GROUP BY "start_year","gender","region","zipcode","T-Level","education" 
HAVING count(*)=1;
-- show the actual counts >= 8
SELECT "start_year", "gender", "region", "zipcode", "T-Level", "education", count(*) as "cnt", MAX("salary") FROM "salaryanon" 
GROUP BY "start_year","gender","region","zipcode","T-Level","education"
ORDER by "cnt" ASC;

-- now do the same but create a function for the zipcode
create or replace function "ZipCodeHierarchy"(value varchar(255), level integer)
returns outValue varchar(255)
as
charsToShow integer default 0;
begin
charsToShow := length(value) - level;
outValue := rpad(substring(value, 1, charsToShow), charsToShow+level,'*');
end;

DROP VIEW "salaryanonHierarchyFunction";

CREATE VIEW "salaryanonHierarchyFunction" ("id", "start_year", "gender", "region", "zipcode", "T-Level", "education", "salary")
AS
SELECT "id", "start_year", "gender", "region", "zipcode", "T-Level", "education", "salary"
FROM "SalarySQLDemo.db::Salaries"
WITH ANONYMIZATION (ALGORITHM 'K-ANONYMITY' PARAMETERS '{"k": 8}'
COLUMN "id" PARAMETERS '{"is_sequence":true}'
COLUMN "gender" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["f"],["m"]]}}'
COLUMN "region" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["APJ"],["EMEA"],["NA"]]}}'
COLUMN "T-Level" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["T1","T1-T2"],["T2","T1-T2"],["T3","T3-T5"],["T4","T3-T5"],["T5","T3-T5"]]}}'
COLUMN "education" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["9th-12th","High School","Secondary Ed"],["Assoc-acdm","Professional Ed","Higher Ed"],["Assoc-voc","Professional Ed","Higher Ed"],["Bachelor","Undergraduate","Higher Ed"],["College","Undergraduate","Higher Ed"],["Doctorate","Graduate","Higher Ed"],["HS-grad","High School","Secondary Ed"],["Master","Graduate","Higher Ed"],["Prof-school","Professional Ed","Higher Ed"]]}}'
-- here is the respective column definition (remaining part stays the same)
COLUMN "zipcode" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"schema":"SALARYSQLDEMO", "function":"ZipCodeHierarchy", "levels":4}}'
COLUMN "start_year" PARAMETERS '{"is_quasi_identifier":true,"hierarchy":{"embedded":[["1987","1986-1990","1986-1995"],["1988","1986-1990","1986-1995"],["1989","1986-1990","1986-1995"],["1990","1986-1990","1986-1995"],["1991","1991-1995","1986-1995"],["1992","1991-1995","1986-1995"],["1993","1991-1995","1986-1995"],["1994","1991-1995","1986-1995"],["1995","1991-1995","1986-1995"],["1996","1996-2000","1996-2005"],["1997","1996-2000","1996-2005"],["1998","1996-2000","1996-2005"],["1999","1996-2000","1996-2005"],["2000","1996-2000","1996-2005"],["2001","2001-2005","1996-2005"],["2002","2001-2005","1996-2005"],["2003","2001-2005","1996-2005"],["2004","2001-2005","1996-2005"],["2005","2001-2005","1996-2005"],["2006","2006-2010",">2006"],["2007","2006-2010",">2006"],["2008","2006-2010",">2006"],["2009","2006-2010",">2006"],["2010","2006-2010",">2006"],["2011","2011-2015",">2006"],["2012","2011-2015",">2006"],["2013","2011-2015",">2006"],["2014","2011-2015",">2006"],["2015","2011-2015",">2006"],["2016","2016-2020",">2006"],["2017","2016-2020",">2006"]]}}');

REFRESH VIEW "salaryanonHierarchyFunction" ANONYMIZATION;

SELECT * FROM "salaryanonHierarchyFunction";

SELECT "start_year", "gender", "region", "zipcode", "T-Level", "education", count(*), MAX("salary") FROM "salaryanonHierarchyFunction" 
GROUP BY "start_year","gender","region","zipcode","T-Level","education" 
HAVING count(*)=1;

-- dropping i case running the demo twice
DROP VIEW "salaryanon_dp";

CREATE VIEW "salaryanon_dp" ("id", "start_year", "gender", "region", "zipcode", "T-Level", "education", "salary")
AS
SELECT "id", "start_year", "gender", "region", "zipcode", "T-Level", "education", "salary"
FROM "SalarySQLDemo.db::Salaries"
WITH ANONYMIZATION (ALGORITHM 'DIFFERENTIAL_PRIVACY' PARAMETERS ''
COLUMN "id" PARAMETERS '{"is_sequence":true}'
COLUMN "salary" PARAMETERS '{"is_sensitive":true, "epsilon" : 0.5, "sensitivity": 100000}');

REFRESH VIEW "salaryanon_dp" ANONYMIZATION;

SELECT * FROM "salaryanon_dp";

select "start_year", AVG("salary") from "salaryanon_dp" group by "start_year" order by "start_year";

select "start_year", AVG("salary") from "SalarySQLDemo.db::Salaries" group by "start_year" order by "start_year";



