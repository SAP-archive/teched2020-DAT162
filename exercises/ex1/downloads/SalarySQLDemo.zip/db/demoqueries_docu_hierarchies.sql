DROP TABLE ILLNESS;
DROP VIEW ILLNESS_K_ANON;

CREATE COLUMN TABLE Illness (
  -- sequence column                                                                                                                                                                                                                                                                          
  ID BIGINT NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  -- identifier                                                                                                                                                                                                                                                                               
  Name VARCHAR(10),
  -- quasi-identifiers (QIDs) (to be generalized)                                                                                                                                                                                                                                             
  GENDER VARCHAR(1) NOT NULL,
  CITY VARCHAR(10) NOT NULL,
  AGE INTEGER NOT NULL,
  WEIGHT DECIMAL NOT NULL,
  -- sensitive data                                                                                                                                                                                                                                                                           
  ILLNESS VARCHAR(10) NOT NULL);

INSERT INTO ILLNESS VALUES ('Paul', 'M', 'Paris', 27, 50.0, 'BRONCHITIS');
INSERT INTO ILLNESS VALUES ('Martin', 'M', 'Munich', 42, 100.0, 'ANGINA');
INSERT INTO ILLNESS VALUES ('Nils', 'M', 'Nice', 50, 130, 'FLU');
INSERT INTO ILLNESS VALUES ('Annika', 'F', 'Munich', 11, 38.0, 'BROKEN LEG');

--In order to define a hierarchy view, a data source table is needed to define parent child relations. Example:
CREATE COLUMN TABLE CITYDATASOURCE (SUCC VARCHAR(100), PRED VARCHAR(100));
--// Level 2
INSERT INTO CITYDATASOURCE VALUES ('Europe', NULL);
INSERT INTO CITYDATASOURCE VALUES ('Asia', NULL);
--// Level 1
INSERT INTO CITYDATASOURCE VALUES ('Germany', 'Europe');
INSERT INTO CITYDATASOURCE VALUES ('France', 'Europe');
INSERT INTO CITYDATASOURCE VALUES ('S. Korea', 'Asia');
--// Level 0
INSERT INTO CITYDATASOURCE VALUES ('Munich', 'Germany');
INSERT INTO CITYDATASOURCE VALUES ('Nice', 'France');
INSERT INTO CITYDATASOURCE VALUES ('Paris', 'France');
INSERT INTO CITYDATASOURCE VALUES ('Seoul', 'S. Korea');
INSERT INTO CITYDATASOURCE VALUES ('Busan', 'S. Korea');
--A NULL value in the parent/predecessor column refers to the topmost element (root). Note that only level 0 values come from the original table.
--Once we have defined our data source table, we can create a hierarchy view on top of it. Example:
CREATE VIEW CITYHIERARCHY AS SELECT * FROM HIERARCHY(SOURCE (SELECT SUCC AS NODE_ID, PRED AS PARENT_ID FROM CITYDATASOURCE) SIBLING ORDER BY PARENT_ID, NODE_ID);


CREATE OR REPLACE FUNCTION hierarchyfunction(value VARCHAR(255), level INTEGER)
RETURNS outValue VARCHAR(8)
AS
BEGIN
DECLARE weight DECIMAL(5,2);
weight := TO_DECIMAL(value, 5,2);
IF (level = 1) THEN
	IF (weight < 50) THEN 
	    outValue := '< 50';
	END IF; 
     IF (weight >=50 AND weight < 100) THEN
	    outValue = '50 - 100';
	END IF;
	IF (weight >=100 and weight < 150) THEN
	    outValue := '100 -150';
	END IF;
	IF (weight >= 150) THEN
	    outValue := '>=150';
	END IF;
END IF;
IF (level = 2) THEN
 	IF (weight < 100) THEN
 	    outValue := '< 100';
	END IF;
	IF (weight >= 100) THEN
	    outValue := '>= 100';
	END IF; 
END IF;
END;



CREATE VIEW ILLNESS_K_ANON (ID, GENDER, LOCATION, AGE, WEIGHT, ILLNESS)
AS SELECT ID, GENDER, CITY AS LOCATION, TO_VARCHAR(AGE) AS AGE, TO_VARCHAR(WEIGHT) AS WEIGHT, ILLNESS FROM ILLNESS
WITH ANONYMIZATION (ALGORITHM 'K-ANONYMITY'
PARAMETERS '{"data_change_strategy": "qualified", "k": 2}'
COLUMN ID PARAMETERS '{"is_sequence": true}'
COLUMN GENDER PARAMETERS '{"is_quasi_identifier":true, "hierarchy":{"embedded": [["F"], ["M"]]}}' -- Json Hierarchy example
COLUMN LOCATION PARAMETERS '{"is_quasi_identifier":true, "hierarchy":{"schema":"SALARYSQLDEMO", "view":"CITYHIERARCHY"}}' -- External Hierarchy example
COLUMN AGE PARAMETERS '{"is_quasi_identifier":true, "hierarchy":{"embedded": [["27", "15"], ["42", "45"], ["50", "45"], ["11", "15"]]}}' -- 0~30 -> 15 -> *, 30~60 -> 45 -> *
COLUMN WEIGHT PARAMETERS '{"is_quasi_identifier":true, "hierarchy":{"schema":"SALARYSQLDEMO", "function":"HIERARCHYFUNCTION", "levels": 4}}'); -- Function Hierarchy example

REFRESH VIEW ILLNESS_K_ANON ANONYMIZATION;

SELECT * FROM Illness_K_Anon;